***********************************************************
``py2neo.server.console`` -- Console for monitoring servers
***********************************************************

.. automodule:: py2neo.server.console
   :members:

*********************************************************
``py2neo.client.http`` -- Low-level HTTP client for Neo4j
*********************************************************

.. automodule:: py2neo.client.http
   :members:

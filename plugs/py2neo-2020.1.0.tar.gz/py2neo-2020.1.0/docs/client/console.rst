*******************************************************
``py2neo.client.console`` -- Interactive client console
*******************************************************

.. automodule:: py2neo.client.console
   :members:

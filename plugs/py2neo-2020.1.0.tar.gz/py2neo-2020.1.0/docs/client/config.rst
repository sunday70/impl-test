************************************************
``py2neo.client.config`` -- Client configuration
************************************************

.. automodule:: py2neo.client.config
   :members:

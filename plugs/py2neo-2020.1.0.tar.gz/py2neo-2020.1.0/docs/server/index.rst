**********************************************************
``py2neo.server`` -- Docker-based runner for Neo4j servers
**********************************************************

.. automodule:: py2neo.server
   :members:

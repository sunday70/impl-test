***************************************
``py2neo.cypher.lexer`` -- Cypher Lexer
***************************************

.. automodule:: py2neo.cypher.lexer
   :members:

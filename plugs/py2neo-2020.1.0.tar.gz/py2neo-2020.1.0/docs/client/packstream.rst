************************************************************
``py2neo.client.packstream`` -- Packstream encoding/decoding
************************************************************

.. automodule:: py2neo.client.packstream
   :members:

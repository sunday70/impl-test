*************************************************
``py2neo.data.spatial`` -- Geo-spatial data types
*************************************************

.. automodule:: py2neo.data.spatial
    :members:

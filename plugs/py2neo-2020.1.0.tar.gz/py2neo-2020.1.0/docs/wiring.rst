*************************************************
``py2neo.wiring`` -- Low-level network operations
*************************************************

.. automodule:: py2neo.wiring
   :members:

***********************************************************
``py2neo.client`` -- Low-level client connections for Neo4j
***********************************************************

.. automodule:: py2neo.client
   :members:

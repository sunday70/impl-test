*******************************************************
``py2neo.ogm.models`` -- Preset models for use with OGM
*******************************************************

.. toctree::
    :maxdepth: 1

    movies

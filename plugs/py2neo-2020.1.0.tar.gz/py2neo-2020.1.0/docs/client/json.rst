*************************************************************
``py2neo.client.json`` -- JSON parsing for the HTTP interface
*************************************************************

.. automodule:: py2neo.client.json
   :members:

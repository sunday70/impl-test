**************************************************
``py2neo.data.operations`` -- Low-level operations
**************************************************

.. automodule:: py2neo.data.operations
    :members:

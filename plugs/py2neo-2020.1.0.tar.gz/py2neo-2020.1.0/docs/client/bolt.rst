*********************************************************
``py2neo.client.bolt`` -- Low-level Bolt client for Neo4j
*********************************************************

.. automodule:: py2neo.client.bolt
   :members:

********************************
The ``py2neo`` command line tool
********************************

Py2neo comes with a command line tool (predictably named `py2neo`) that allows much of its functionality to be accessed from outside of a Python application.
This tool includes an interactive console that can be used for running Cypher queries and facilities for managing auth files.

For full details, run `py2neo --help`.

